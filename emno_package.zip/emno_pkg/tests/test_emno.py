"""
tests/test_emno.py
==================
Unit tests for the EMNO package.
Run with: pytest tests/
"""

import math
import numpy as np
import pytest
import sys
import os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from emno import EMNO, EMNOParams, EMNOResult
from emno.benchmarks import get_function, list_functions


# ─────────────────────────────────────────────────────────────────────────────
# Fixtures
# ─────────────────────────────────────────────────────────────────────────────

@pytest.fixture
def sphere():
    return lambda x: float(np.sum(x**2))

@pytest.fixture
def default_emno():
    return EMNO(EMNOParams(n_agents=20, max_iter=200, seed=42))


# ─────────────────────────────────────────────────────────────────────────────
# Basic tests
# ─────────────────────────────────────────────────────────────────────────────

class TestReturnType:
    def test_returns_emno_result(self, default_emno, sphere):
        result = default_emno.optimize(sphere, lb=-100, ub=100, dim=10)
        assert isinstance(result, EMNOResult)

    def test_best_score_is_float(self, default_emno, sphere):
        result = default_emno.optimize(sphere, lb=-100, ub=100, dim=10)
        assert isinstance(result.best_score, float)

    def test_best_position_shape(self, default_emno, sphere):
        dim = 10
        result = default_emno.optimize(sphere, lb=-100, ub=100, dim=dim)
        assert result.best_position.shape == (dim,)

    def test_convergence_length(self, default_emno, sphere):
        max_iter = 200
        result = default_emno.optimize(sphere, lb=-100, ub=100, dim=10)
        assert len(result.convergence) == max_iter

    def test_convergence_non_increasing(self, default_emno, sphere):
        result = default_emno.optimize(sphere, lb=-100, ub=100, dim=10)
        c = result.convergence
        assert np.all(np.diff(c) <= 1e-12), "Convergence should be non-increasing"

    def test_n_iter_positive(self, default_emno, sphere):
        result = default_emno.optimize(sphere, lb=-100, ub=100, dim=10)
        assert result.n_iter > 0

    def test_n_feval_positive(self, default_emno, sphere):
        result = default_emno.optimize(sphere, lb=-100, ub=100, dim=10)
        assert result.n_feval > 0


# ─────────────────────────────────────────────────────────────────────────────
# Bounds tests
# ─────────────────────────────────────────────────────────────────────────────

class TestBounds:
    def test_scalar_bounds(self, sphere):
        emno = EMNO(EMNOParams(n_agents=15, max_iter=100, seed=0))
        result = emno.optimize(sphere, lb=-50, ub=50, dim=5)
        assert np.all(result.best_position >= -50)
        assert np.all(result.best_position <= 50)

    def test_array_bounds(self, sphere):
        lb = np.array([-10, -20, -30])
        ub = np.array([10,  20,  30])
        emno = EMNO(EMNOParams(n_agents=15, max_iter=100, seed=0))
        result = emno.optimize(sphere, lb=lb, ub=ub, dim=3)
        assert np.all(result.best_position >= lb)
        assert np.all(result.best_position <= ub)


# ─────────────────────────────────────────────────────────────────────────────
# Convergence quality tests
# ─────────────────────────────────────────────────────────────────────────────

class TestConvergenceQuality:
    def test_sphere_d10(self):
        emno = EMNO(EMNOParams(n_agents=30, max_iter=500, seed=1))
        result = emno.optimize(
            lambda x: float(np.sum(x**2)), lb=-100, ub=100, dim=10
        )
        assert result.best_score < 1e-10, (
            f"Sphere D=10 expected < 1e-10, got {result.best_score:.3e}"
        )

    def test_sphere_d30(self):
        emno = EMNO(EMNOParams(n_agents=30, max_iter=1000, seed=2))
        result = emno.optimize(
            lambda x: float(np.sum(x**2)), lb=-100, ub=100, dim=30
        )
        assert result.best_score < 1e-6, (
            f"Sphere D=30 expected < 1e-6, got {result.best_score:.3e}"
        )

    def test_rastrigin_d10(self):
        emno = EMNO(EMNOParams(n_agents=30, max_iter=500, seed=3))
        result = emno.optimize(
            lambda x: float(10*len(x) + np.sum(x**2 - 10*np.cos(2*math.pi*x))),
            lb=-5.12, ub=5.12, dim=10
        )
        assert result.best_score < 10.0, (
            f"Rastrigin D=10 expected < 10, got {result.best_score:.3e}"
        )

    def test_best_position_evaluated_correctly(self, sphere):
        emno = EMNO(EMNOParams(n_agents=20, max_iter=200, seed=4))
        result = emno.optimize(sphere, lb=-100, ub=100, dim=5)
        reeval = sphere(result.best_position)
        assert abs(reeval - result.best_score) < 1e-12 or reeval <= result.best_score


# ─────────────────────────────────────────────────────────────────────────────
# Reproducibility
# ─────────────────────────────────────────────────────────────────────────────

class TestReproducibility:
    def test_same_seed_same_result(self, sphere):
        emno1 = EMNO(EMNOParams(n_agents=20, max_iter=100, seed=99))
        emno2 = EMNO(EMNOParams(n_agents=20, max_iter=100, seed=99))
        r1 = emno1.optimize(sphere, lb=-100, ub=100, dim=10)
        r2 = emno2.optimize(sphere, lb=-100, ub=100, dim=10)
        assert r1.best_score == r2.best_score
        np.testing.assert_array_equal(r1.best_position, r2.best_position)

    def test_different_seeds_different_results(self, sphere):
        emno1 = EMNO(EMNOParams(n_agents=20, max_iter=100, seed=1))
        emno2 = EMNO(EMNOParams(n_agents=20, max_iter=100, seed=2))
        r1 = emno1.optimize(sphere, lb=-100, ub=100, dim=10)
        r2 = emno2.optimize(sphere, lb=-100, ub=100, dim=10)
        # Not guaranteed to differ but almost certain for different seeds
        # Just check both complete without error
        assert r1.n_iter > 0 and r2.n_iter > 0


# ─────────────────────────────────────────────────────────────────────────────
# Benchmarks registry
# ─────────────────────────────────────────────────────────────────────────────

class TestBenchmarks:
    def test_list_functions_nonempty(self):
        funcs = list_functions()
        assert len(funcs) > 0

    def test_get_function_sphere(self):
        bf = get_function("sphere")
        assert bf.name == "Sphere"
        assert bf.optimum == 0.0

    def test_get_function_unknown_raises(self):
        with pytest.raises(KeyError):
            get_function("nonexistent_function_xyz")

    def test_all_functions_callable(self):
        for name in list_functions():
            bf = get_function(name)
            x = np.zeros(bf.dim)
            val = bf.func(x)
            assert isinstance(val, float)


# ─────────────────────────────────────────────────────────────────────────────
# Edge cases
# ─────────────────────────────────────────────────────────────────────────────

class TestEdgeCases:
    def test_dim_1(self):
        emno = EMNO(EMNOParams(n_agents=10, max_iter=100, seed=0))
        result = emno.optimize(lambda x: float(x[0]**2), lb=-10, ub=10, dim=1)
        assert result.best_score >= 0.0

    def test_dim_100(self):
        emno = EMNO(EMNOParams(n_agents=30, max_iter=100, seed=0))
        result = emno.optimize(
            lambda x: float(np.sum(x**2)), lb=-100, ub=100, dim=100
        )
        assert result.best_score >= 0.0

    def test_early_stop(self):
        emno = EMNO(EMNOParams(n_agents=30, max_iter=1000, seed=0, tol=1e-10))
        result = emno.optimize(
            lambda x: float(np.sum(x**2)), lb=-100, ub=100, dim=10
        )
        # Should stop early when tol is met
        assert result.n_iter <= 1000

    def test_small_population(self):
        emno = EMNO(EMNOParams(n_agents=5, max_iter=50, seed=0))
        result = emno.optimize(
            lambda x: float(np.sum(x**2)), lb=-10, ub=10, dim=5
        )
        assert result.best_score >= 0.0
