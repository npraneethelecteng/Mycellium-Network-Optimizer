"""
emno/core.py
============
Enhanced Mycelium Network Optimization (EMNO) — core algorithm.

Faithful Python port of EMNO v5 (MATLAB canonical implementation).
Enhancements over original MNO:
    E1 — Chaotic tent-map initialisation
    E2 — Energy-based HHO besiege (soft/hard, adaptive probability)
    E3 — DE/best/1 mutation with adaptive scale factor + binomial crossover
    E4 — HHO rapid dive with Lévy flight toward population mean
    E5 — SCA perturbation layer gated by precision threshold
    E6 — Adaptive restart (stagnation counter, dynamic threshold)

Precision: uses Python float64 (IEEE 754 double) throughout.
No artificial lower bound on convergence — algorithm converges to
machine epsilon (~2.2e-16) on unimodal functions.
"""

from __future__ import annotations

import math
import warnings
from dataclasses import dataclass, field
from typing import Callable, Optional, Union

import numpy as np

__all__ = ["EMNO", "EMNOResult", "EMNOParams"]

# ─────────────────────────────────────────────────────────────────────────────
# Data classes
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class EMNOParams:
    """
    Hyper-parameters for EMNO.  Defaults match the published MATLAB v5.

    Parameters
    ----------
    n_agents : int
        Population size.  Default 30.
    max_iter : int
        Maximum number of iterations.  Default 500.
    elite_frac : float
        Fraction of population preserved on restart.  Default 0.33.
    restart_window : int
        Stagnation iterations before restart fires.  Default 25.
    restart_frac : float
        Fraction of bottom population reinitialised on restart.  Default 0.45.
    sca_gate : float
        SCA perturbation disabled when best fitness ≤ sca_gate.  Default 1e-6.
    levy_beta : float
        Lévy flight stability index β.  Default 1.5.
    de_cr : float
        DE binomial crossover probability.  Default 0.9.
    alpha : float
        Decay rate for D1, D2 schedules.  Default 4.5.
    beta_mno : float
        MNO logistic decay rate.  Default 4.0.
    gamma_mno : float
        Power-law decay exponent.  Default 2.8.
    delta_mno : float
        Convergence sharpness exponent.  Default 2.0.
    prec : float
        Precision scaling factor.  Default 2.0.
    kappa : float
        Active-agent decay rate.  Default 3.5.
    spiral_param : float
        MNO spiral parameter.  Default 2.5.
    tol : float
        Early-stop tolerance.  Set to 0 to disable.  Default 0.
    seed : int or None
        Random seed for reproducibility.  Default None.
    verbose : bool
        Print progress every 50 iterations.  Default False.
    """
    n_agents:       int   = 30
    max_iter:       int   = 500
    elite_frac:     float = 0.33
    restart_window: int   = 25
    restart_frac:   float = 0.45
    sca_gate:       float = 1e-6
    levy_beta:      float = 1.5
    de_cr:          float = 0.9
    alpha:          float = 4.5
    beta_mno:       float = 4.0
    gamma_mno:      float = 2.8
    delta_mno:      float = 2.0
    prec:           float = 2.0
    kappa:          float = 3.5
    spiral_param:   float = 2.5
    tol:            float = 0.0
    seed:           Optional[int] = None
    verbose:        bool  = False


@dataclass
class EMNOResult:
    """
    Result object returned by :func:`EMNO.optimize`.

    Attributes
    ----------
    best_score : float
        Best objective function value found.
    best_position : np.ndarray
        Parameter vector corresponding to best_score.
    convergence : np.ndarray
        Best score recorded at each iteration.
    n_iter : int
        Number of iterations actually executed.
    n_feval : int
        Total number of function evaluations.
    """
    best_score:    float
    best_position: np.ndarray
    convergence:   np.ndarray
    n_iter:        int
    n_feval:       int


# ─────────────────────────────────────────────────────────────────────────────
# Helpers
# ─────────────────────────────────────────────────────────────────────────────

def _levy_step(dim: int, beta: float, rng: np.random.Generator) -> np.ndarray:
    """
    Mantegna's algorithm for Lévy flight step vector.

    Returns a vector of shape (dim,) with heavy-tailed distribution.
    Steps are clipped to [-10, 10] to prevent blow-up.
    """
    num = math.gamma(1.0 + beta) * math.sin(math.pi * beta / 2.0)
    den = math.gamma((1.0 + beta) / 2.0) * beta * (2.0 ** ((beta - 1.0) / 2.0))
    sigma = (num / den) ** (1.0 / beta)
    u = rng.standard_normal(dim) * sigma
    v = np.abs(rng.standard_normal(dim)) + 1e-300   # avoid div-by-zero
    step = u / (v ** (1.0 / beta))
    return np.clip(step, -10.0, 10.0)


def _tent_map_init(
    n: int,
    dim: int,
    lb: np.ndarray,
    ub: np.ndarray,
    rng: np.random.Generator,
) -> np.ndarray:
    """
    Chaotic tent-map initialisation (E1).

    Generates an n×dim population with more uniform coverage than
    uniform random, using an ergodic tent-map trajectory.
    """
    X = np.empty((n, dim), dtype=np.float64)
    x = rng.random(dim)          # random starting state per dimension
    for i in range(n):
        mask = x < 0.7
        x = np.where(mask, x / 0.7, (1.0 - x) / 0.3)
        X[i] = lb + x * (ub - lb)
    return X


def _clip(X: np.ndarray, lb: np.ndarray, ub: np.ndarray) -> np.ndarray:
    return np.clip(X, lb, ub)


# ─────────────────────────────────────────────────────────────────────────────
# Main class
# ─────────────────────────────────────────────────────────────────────────────

class EMNO:
    """
    Enhanced Mycelium Network Optimization (EMNO).

    Parameters
    ----------
    params : EMNOParams, optional
        Algorithm hyper-parameters.  Uses defaults if not provided.

    Examples
    --------
    >>> import numpy as np
    >>> from emno import EMNO
    >>> sphere = lambda x: float(np.sum(x**2))
    >>> result = EMNO().optimize(sphere, lb=-100, ub=100, dim=30)
    >>> print(result.best_score)
    """

    def __init__(self, params: Optional[EMNOParams] = None) -> None:
        self.params = params or EMNOParams()

    # ------------------------------------------------------------------ #

    def optimize(
        self,
        fobj: Callable[[np.ndarray], float],
        lb: Union[float, list, np.ndarray],
        ub: Union[float, list, np.ndarray],
        dim: int,
    ) -> EMNOResult:
        """
        Run EMNO on objective function *fobj*.

        Parameters
        ----------
        fobj : callable
            Objective function.  Signature: ``f(x: np.ndarray) -> float``.
            Minimisation is assumed.
        lb : float | array-like
            Lower bound(s).  Scalar is broadcast to all dimensions.
        ub : float | array-like
            Upper bound(s).  Scalar is broadcast to all dimensions.
        dim : int
            Problem dimensionality.

        Returns
        -------
        EMNOResult
        """
        p = self.params
        rng = np.random.default_rng(p.seed)

        # ── Bounds ──────────────────────────────────────────────────────
        lb = np.broadcast_to(np.atleast_1d(np.float64(lb)), (dim,)).copy()
        ub = np.broadcast_to(np.atleast_1d(np.float64(ub)), (dim,)).copy()

        N        = p.n_agents
        MAX_ITER = p.max_iter

        # ── E1 Chaotic tent-map initialisation ──────────────────────────
        X = _tent_map_init(N, dim, lb, ub, rng)

        # ── MNO fixed parameters ────────────────────────────────────────
        PHI   = (1.0 + math.sqrt(5.0)) / 2.0
        alpha = p.alpha
        beta_m= p.beta_mno
        gamma = p.gamma_mno
        delta = p.delta_mno
        prec  = p.prec
        kappa = p.kappa
        spt   = p.spiral_param

        # ── State ────────────────────────────────────────────────────────
        convergence = np.full(MAX_ITER, np.inf)
        mem_sites   = np.empty((N, dim))
        mem_scores  = np.full(N, np.inf)
        best_stag   = np.inf
        stag_ctr    = 0
        n_feval     = 0

        Best_score: float = np.inf
        Best_pos   = np.empty(dim)

        # ── Main loop ────────────────────────────────────────────────────
        for iteration in range(MAX_ITER):
            t = (iteration + 1) / MAX_ITER          # normalised time ∈ (0,1]

            # ── Evaluate + clip ─────────────────────────────────────────
            fit = np.empty(N)
            for i in range(N):
                X[i] = _clip(X[i], lb, ub)
                fit[i] = float(fobj(X[i]))
            n_feval += N

            # ── Memory / archive update ──────────────────────────────────
            if iteration == 0:
                order = np.argsort(fit)
                mem_sites  = X[order].copy()
                mem_scores = fit[order].copy()
            else:
                combined_X = np.vstack([X, mem_sites])
                combined_f = np.concatenate([fit, mem_scores])
                order      = np.argsort(combined_f)
                mem_sites  = combined_X[order[:N]].copy()
                mem_scores = combined_f[order[:N]].copy()

            Best_score = float(mem_scores[0])
            Best_pos   = mem_sites[0].copy()

            convergence[iteration] = Best_score

            # ── E6 Adaptive restart ──────────────────────────────────────
            if Best_score < best_stag * 0.99:
                best_stag = Best_score
                stag_ctr  = 0
            else:
                stag_ctr += 1

            restart_gate = max(1e-300, Best_score * 0.01)
            if stag_ctr >= p.restart_window and Best_score > restart_gate:
                n_elite   = max(1, int(p.elite_frac * N))
                n_restart = int(p.restart_frac * N)
                for k in range(n_restart):
                    idx = N - 1 - k
                    if idx >= n_elite:
                        X[idx] = lb + rng.random(dim) * (ub - lb)
                stag_ctr  = 0
                best_stag = Best_score

            # ── Verbose ──────────────────────────────────────────────────
            if p.verbose and (iteration + 1) % 50 == 0:
                print(f"  Iter {iteration+1:4d}/{MAX_ITER}  "
                      f"Best = {Best_score:.6e}")

            # ── Early stop ───────────────────────────────────────────────
            if p.tol > 0 and Best_score <= p.tol:
                convergence[iteration:] = Best_score
                return EMNOResult(
                    best_score=Best_score,
                    best_position=Best_pos.copy(),
                    convergence=convergence,
                    n_iter=iteration + 1,
                    n_feval=n_feval,
                )

            # ── Decay schedule ───────────────────────────────────────────
            D1      = math.exp(-alpha * t)
            D2      = math.exp(-alpha * prec * t * t)
            L_decay = 1.0 / (1.0 + beta_m * math.log1p(10.0 * t))
            Pt      = (1.0 - t) ** gamma
            Fs      = max(t, 1e-300) ** (1.0 / delta)
            Psi     = D1 * D2 * L_decay
            Active  = max(1, round(N * math.exp(-kappa * t) * Pt))
            sp_lo   = -1.0 - 1.5 * t

            # Normalised scores for spiral step
            f_range = mem_scores.max() - mem_scores.min() + 1e-300
            NS = ((mem_scores.max() - mem_scores) / f_range) ** (1.0 / delta)

            # E2 energy
            E0   = 2.0 * rng.random() - 1.0
            E    = 2.0 * E0 * (1.0 - t)
            Eabs = abs(E)

            sca_r1     = 2.0 - t * 2.0             # SCA amplitude a(t)
            DE_F       = 0.5 * (1.0 + math.sin(math.pi * t))   # E3 scale
            p_besiege  = 0.2 + 0.5 * t             # E2 probability
            Xmean      = X.mean(axis=0)             # E4 population mean
            na         = min(Active, N)

            # ── Per-agent update ─────────────────────────────────────────
            for i in range(N):
                xi = X[i].copy()

                if Eabs >= 1.0:
                    # Global exploration: random jump
                    ridx = rng.integers(0, N)
                    Xr   = X[ridx].copy()
                    A    = 2.0 * Eabs * rng.random(dim) - Eabs
                    C    = 2.0 * rng.random(dim)
                    xi   = Xr - A * np.abs(C * Xr - xi)

                else:
                    rand_p = rng.random()

                    if rand_p < p_besiege:
                        # E2 besiege
                        if Eabs >= 0.5:
                            JS = 2.0 * rng.random() - 1.0
                            xi = Best_pos - xi - Eabs * np.abs(JS * Best_pos - xi)
                        else:
                            xi = Best_pos - Eabs * np.abs(Best_pos - xi)

                    elif rand_p < p_besiege + 0.25 * (1.0 - t) and i < na:
                        # MNO spiral
                        tgt  = mem_sites[i].copy()
                        dist = np.abs(tgt - xi)
                        t_sp = (sp_lo - 1.0) * rng.random(dim) + 1.0
                        theta = t_sp * 2.0 * math.pi / PHI
                        comp = (dist
                                * np.exp(spt * Psi * t_sp)
                                * np.cos(theta))
                        xi = tgt + comp * Psi

                    elif (rand_p < p_besiege + 0.25 * (1.0 - t) + 0.15 * (1.0 - t)
                          and N >= 4):
                        # E3 DE/best/1 mutation
                        candidates = np.delete(np.arange(N), i)
                        r1, r2 = rng.choice(candidates, size=2, replace=False)
                        v = _clip(
                            Best_pos + DE_F * (mem_sites[r1] - mem_sites[r2]),
                            lb, ub,
                        )
                        cross = rng.random(dim) < p.de_cr
                        xi = np.where(cross, v, xi)

                    elif i < na:
                        # MNO direct convergence
                        tgt  = mem_sites[i].copy()
                        dist = np.abs(tgt - xi)
                        xi   = xi + (np.sign(tgt - xi)
                                     * dist * L_decay * D1
                                     * (0.8 + 0.2 * NS[i]))

                    else:
                        # E4 HHO rapid dive with Lévy
                        JS = 2.0 * rng.random() - 1.0
                        if rng.random() < 0.5:
                            Xc1 = Best_pos - xi - Eabs * np.abs(JS * Best_pos - xi)
                            Lv  = _levy_step(dim, p.levy_beta, rng)
                            Xc2 = (Best_pos
                                   - Eabs * np.abs(JS * Best_pos - Xmean)
                                   + Lv * 0.01 * (ub - lb) * Psi)
                            Xc1 = _clip(Xc1, lb, ub)
                            Xc2 = _clip(Xc2, lb, ub)
                            f1 = float(fobj(Xc1))
                            f2 = float(fobj(Xc2))
                            n_feval += 2
                            xi = Xc1 if f1 <= f2 else Xc2
                        else:
                            bidx = min(Active - 1, len(mem_sites) - 1)
                            tb   = mem_sites[bidx].copy()
                            db   = np.abs(tb - xi)
                            ec   = Psi * L_decay * prec
                            pm   = db ** (1.0 / gamma) * ec
                            xi   = xi + np.sign(tb - xi) * pm * 0.9

                # E5 SCA perturbation (gated)
                if Best_score > p.sca_gate:
                    r2_sca = 2.0 * math.pi * rng.random(dim)
                    r3_sca = rng.random(dim)
                    if rng.random() < 0.5:
                        xi = xi + sca_r1 * np.sin(r2_sca) * np.abs(r3_sca * Best_pos - xi)
                    else:
                        xi = xi + sca_r1 * np.cos(r2_sca) * np.abs(r3_sca * Best_pos - xi)

                # Fractal noise (original MNO)
                xi = xi + (2.0 * rng.random(dim) - 1.0) * (ub - lb) * 0.001 * Fs * Psi

                X[i] = _clip(xi, lb, ub)

        return EMNOResult(
            best_score=float(Best_score),
            best_position=Best_pos.copy(),
            convergence=convergence,
            n_iter=MAX_ITER,
            n_feval=n_feval,
        )
