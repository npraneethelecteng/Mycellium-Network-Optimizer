"""
EMNO — Enhanced Mycelium Network Optimization
==============================================

A bio-inspired metaheuristic optimizer with six targeted enhancements
over the original Mycelium Network Optimization (MNO) algorithm.

Quick start
-----------
>>> from emno import EMNO
>>> import numpy as np
>>> result = EMNO().optimize(lambda x: float(np.sum(x**2)), lb=-100, ub=100, dim=30)
>>> print(result.best_score)
"""

from .core import EMNO, EMNOParams, EMNOResult
from .benchmarks import get_function, list_functions
from .utils import plot_convergence, run_benchmark

__version__ = "1.0.0"
__author__  = "Dr. N Praneeth"
__all__     = [
    "EMNO", "EMNOParams", "EMNOResult",
    "get_function", "list_functions",
    "plot_convergence", "run_benchmark",
]
