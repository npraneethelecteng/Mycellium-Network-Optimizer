"""
emno/utils.py
=============
Plotting and benchmarking utilities.
"""

from __future__ import annotations

import time
from typing import List, Optional, Union

import numpy as np

__all__ = ["plot_convergence", "run_benchmark", "statistical_summary"]


def plot_convergence(
    convergence: Union[np.ndarray, List[np.ndarray]],
    labels:      Optional[List[str]] = None,
    title:       str = "Convergence Curve",
    log_scale:   bool = True,
    save_path:   Optional[str] = None,
) -> None:
    """
    Plot one or more convergence curves.

    Parameters
    ----------
    convergence : ndarray or list of ndarrays
        Single curve or list of curves to overlay.
    labels : list of str, optional
        Legend labels for each curve.
    title : str
        Plot title.
    log_scale : bool
        Use log scale on y-axis.  Default True.
    save_path : str, optional
        If given, save figure to this path instead of displaying.
    """
    try:
        import matplotlib.pyplot as plt
    except ImportError:
        raise ImportError("matplotlib is required for plotting. "
                          "Install with: pip install matplotlib")

    fig, ax = plt.subplots(figsize=(8, 5))

    if isinstance(convergence, np.ndarray):
        convergence = [convergence]

    if labels is None:
        labels = [f"Run {i+1}" for i in range(len(convergence))]

    for curve, label in zip(convergence, labels):
        iters = np.arange(1, len(curve) + 1)
        ax.plot(iters, curve, linewidth=1.8, label=label)

    ax.set_xlabel("Iteration", fontsize=12)
    ax.set_ylabel("Best Fitness", fontsize=12)
    ax.set_title(title, fontsize=13)
    if log_scale:
        ax.set_yscale("symlog", linthresh=1e-300)
    ax.legend(fontsize=10)
    ax.grid(True, alpha=0.3)
    plt.tight_layout()

    if save_path:
        plt.savefig(save_path, dpi=150, bbox_inches="tight")
        plt.close(fig)
    else:
        plt.show()


def run_benchmark(
    optimizer,
    fobj,
    lb, ub, dim,
    n_runs:  int = 30,
    verbose: bool = True,
) -> dict:
    """
    Run the optimizer multiple times and return statistical summary.

    Parameters
    ----------
    optimizer : EMNO instance
        Configured optimizer.
    fobj : callable
        Objective function.
    lb, ub : float or array-like
        Search bounds.
    dim : int
        Problem dimensionality.
    n_runs : int
        Number of independent runs.  Default 30.
    verbose : bool
        Print progress.

    Returns
    -------
    dict with keys:
        scores, mean, std, best, worst, median, time_total, convergences
    """
    scores      = []
    convergences = []
    t0          = time.perf_counter()

    for run in range(1, n_runs + 1):
        result = optimizer.optimize(fobj, lb=lb, ub=ub, dim=dim)
        scores.append(result.best_score)
        convergences.append(result.convergence)
        if verbose:
            print(f"  Run {run:2d}/{n_runs}  best = {result.best_score:.6e}")

    scores = np.array(scores)
    elapsed = time.perf_counter() - t0

    summary = {
        "scores":      scores,
        "mean":        float(np.mean(scores)),
        "std":         float(np.std(scores)),
        "best":        float(np.min(scores)),
        "worst":       float(np.max(scores)),
        "median":      float(np.median(scores)),
        "time_total":  elapsed,
        "convergences": convergences,
    }

    if verbose:
        print(f"\n  Mean  ± Std  : {summary['mean']:.4e} ± {summary['std']:.4e}")
        print(f"  Best / Worst : {summary['best']:.4e} / {summary['worst']:.4e}")
        print(f"  Total time   : {elapsed:.2f}s")

    return summary


def statistical_summary(results: dict) -> str:
    """
    Return a formatted string of benchmark statistics.

    Parameters
    ----------
    results : dict
        Output of :func:`run_benchmark`.
    """
    return (
        f"Mean: {results['mean']:.4e}  "
        f"Std: {results['std']:.4e}  "
        f"Best: {results['best']:.4e}  "
        f"Worst: {results['worst']:.4e}  "
        f"Median: {results['median']:.4e}"
    )
