"""
emno/benchmarks.py
==================
Classic benchmark functions for testing EMNO.
All functions are minimisation problems.
"""

from __future__ import annotations
import math
import numpy as np
from typing import Callable, Dict, NamedTuple

__all__ = ["get_function", "list_functions", "BenchmarkFunction"]


class BenchmarkFunction(NamedTuple):
    name:     str
    func:     Callable
    lb:       float
    ub:       float
    dim:      int
    optimum:  float


# ─────────────────────────────────────────────────────────────────────────────
# Function definitions
# ─────────────────────────────────────────────────────────────────────────────

def sphere(x: np.ndarray) -> float:
    return float(np.sum(x ** 2))

def schwefel_222(x: np.ndarray) -> float:
    return float(np.sum(np.abs(x)) + np.prod(np.abs(x)))

def powell(x: np.ndarray) -> float:
    d = len(x)
    d = d - (d % 4)
    s = 0.0
    for i in range(0, d, 4):
        s += ((x[i] + 10 * x[i+1]) ** 2
              + 5 * (x[i+2] - x[i+3]) ** 2
              + (x[i+1] - 2 * x[i+2]) ** 4
              + 10 * (x[i] - x[i+3]) ** 4)
    return float(s)

def rosenbrock(x: np.ndarray) -> float:
    return float(np.sum(100.0 * (x[1:] - x[:-1]**2)**2 + (x[:-1] - 1)**2))

def step(x: np.ndarray) -> float:
    return float(np.sum((np.floor(x + 0.5)) ** 2))

def quartic(x: np.ndarray) -> float:
    d = len(x)
    return float(np.sum(np.arange(1, d+1) * x**4) + np.random.rand())

def schwefel_226(x: np.ndarray) -> float:
    return float(418.9829 * len(x) - np.sum(x * np.sin(np.sqrt(np.abs(x)))))

def rastrigin(x: np.ndarray) -> float:
    d = len(x)
    return float(10 * d + np.sum(x**2 - 10 * np.cos(2 * math.pi * x)))

def ackley(x: np.ndarray) -> float:
    d   = len(x)
    a, b, c = 20.0, 0.2, 2.0 * math.pi
    s1  = np.sum(x**2)
    s2  = np.sum(np.cos(c * x))
    return float(-a * math.exp(-b * math.sqrt(s1 / d))
                 - math.exp(s2 / d)
                 + a + math.e)

def griewank(x: np.ndarray) -> float:
    d   = len(x)
    s   = np.sum(x**2) / 4000.0
    p   = np.prod(np.cos(x / np.sqrt(np.arange(1, d+1))))
    return float(s - p + 1.0)

def penalized1(x: np.ndarray) -> float:
    def u(xi, a, k, m):
        return np.where(xi > a,  k * (xi - a)**m,
               np.where(xi < -a, k * (-xi - a)**m, 0.0))
    d  = len(x)
    y  = 1.0 + (x + 1.0) / 4.0
    s  = 10.0 * np.sin(math.pi * y[0])**2
    s += np.sum((y[:-1] - 1)**2 * (1 + 10 * np.sin(math.pi * y[1:])**2))
    s += (y[-1] - 1)**2
    s *= math.pi / d
    s += np.sum(u(x, 10.0, 100.0, 4.0))
    return float(s)

def penalized2(x: np.ndarray) -> float:
    def u(xi, a, k, m):
        return np.where(xi > a,  k * (xi - a)**m,
               np.where(xi < -a, k * (-xi - a)**m, 0.0))
    s  = np.sin(3.0 * math.pi * x[0])**2
    s += np.sum((x[:-1] - 1)**2 * (1 + np.sin(3 * math.pi * x[1:])**2))
    s += (x[-1] - 1)**2 * (1 + np.sin(2 * math.pi * x[-1])**2)
    s += np.sum(u(x, 5.0, 100.0, 4.0))
    return float(0.1 * s)

def weierstrass(x: np.ndarray) -> float:
    a, b, k_max = 0.5, 3.0, 20
    d = len(x)
    ks = np.arange(0, k_max + 1)
    s  = 0.0
    for xi in x:
        s += np.sum(a**ks * np.cos(2 * math.pi * b**ks * (xi + 0.5)))
    s -= d * np.sum(a**ks * np.cos(math.pi * b**ks))
    return float(s)


# ─────────────────────────────────────────────────────────────────────────────
# Registry
# ─────────────────────────────────────────────────────────────────────────────

_REGISTRY: Dict[str, BenchmarkFunction] = {
    "sphere":       BenchmarkFunction("Sphere",        sphere,       -100, 100, 30, 0.0),
    "schwefel222":  BenchmarkFunction("Schwefel 2.22", schwefel_222, -10,  10,  30, 0.0),
    "powell":       BenchmarkFunction("Powell",        powell,       -4,   5,   24, 0.0),
    "rosenbrock":   BenchmarkFunction("Rosenbrock",    rosenbrock,   -30,  30,  30, 0.0),
    "step":         BenchmarkFunction("Step",          step,         -100, 100, 30, 0.0),
    "quartic":      BenchmarkFunction("Quartic",       quartic,      -1.28,1.28,30, 0.0),
    "schwefel226":  BenchmarkFunction("Schwefel 2.26", schwefel_226, -500, 500, 30, 0.0),
    "rastrigin":    BenchmarkFunction("Rastrigin",     rastrigin,    -5.12,5.12,30, 0.0),
    "ackley":       BenchmarkFunction("Ackley",        ackley,       -32,  32,  30, 0.0),
    "griewank":     BenchmarkFunction("Griewank",      griewank,     -600, 600, 30, 0.0),
    "penalized1":   BenchmarkFunction("Penalized-1",   penalized1,   -50,  50,  30, 0.0),
    "penalized2":   BenchmarkFunction("Penalized-2",   penalized2,   -50,  50,  30, 0.0),
    "weierstrass":  BenchmarkFunction("Weierstrass",   weierstrass,  -0.5, 0.5, 30, 0.0),
}


def get_function(name: str) -> BenchmarkFunction:
    """Return a :class:`BenchmarkFunction` by name (case-insensitive)."""
    key = name.lower().replace(" ", "").replace("-", "").replace("_", "")
    if key not in _REGISTRY:
        raise KeyError(f"Unknown benchmark '{name}'. "
                       f"Available: {list(_REGISTRY.keys())}")
    return _REGISTRY[key]


def list_functions() -> list:
    """Return list of available benchmark function names."""
    return list(_REGISTRY.keys())
