"""
setup.py for EMNO package
"""
from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as f:
    long_description = f.read()

setup(
    name="emno",
    version="1.0.0",
    author="Dr. N Praneeth",
    author_email="praneeth@woxsen.edu.in",
    description="Enhanced Mycelium Network Optimization (EMNO) algorithm",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/npraneeth/emno",
    packages=find_packages(exclude=["tests*", "examples*", "docs*"]),
    python_requires=">=3.8",
    install_requires=[
        "numpy>=1.21.0",
    ],
    extras_require={
        "plot": ["matplotlib>=3.4.0"],
        "dev":  ["pytest>=7.0", "matplotlib>=3.4.0"],
    },
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Topic :: Scientific/Engineering :: Artificial Intelligence",
        "Intended Audience :: Science/Research",
    ],
    keywords="optimization metaheuristic swarm-intelligence bio-inspired",
)
