# EMNO — Enhanced Mycelium Network Optimization

[![Python](https://img.shields.io/badge/python-3.8%2B-blue)](https://www.python.org/)
[![License: MIT](https://img.shields.io/badge/License-MIT-green.svg)](LICENSE)
[![NumPy](https://img.shields.io/badge/numpy-1.21%2B-orange)](https://numpy.org/)

A high-precision Python implementation of the **Enhanced Mycelium Network Optimization (EMNO)** algorithm — a bio-inspired metaheuristic optimizer with six targeted enhancements over the original MNO, achieving superior convergence on unimodal, multimodal, and engineering design benchmark problems.

---

## Enhancements over MNO

| # | Enhancement | Mechanism |
|---|---|---|
| E1 | Chaotic tent-map initialisation | Ergodic tent-map for uniform spatial coverage |
| E2 | Energy-based besiege | Soft/hard besiege with adaptive probability |
| E3 | DE/best/1 mutation | Differential evolution with sinusoidal scale factor |
| E4 | HHO rapid dive + Lévy | Two-option dive with heavy-tailed Lévy flight toward population mean |
| E5 | Gated SCA perturbation | SCA disabled below precision threshold |
| E6 | Adaptive restart | Stagnation counter with dynamic threshold |

---

## Installation

```bash
# From PyPI (once published)
pip install emno

# From source
git clone https://github.com/npraneeth/emno.git
cd emno
pip install -e .

# With plotting support
pip install -e ".[plot]"
```

---

## Quick Start

```python
import numpy as np
from emno import EMNO

# Define objective (minimisation)
def sphere(x):
    return float(np.sum(x**2))

# Run with defaults
result = EMNO().optimize(sphere, lb=-100, ub=100, dim=30)

print(f"Best score : {result.best_score:.6e}")
print(f"Best pos   : {result.best_position}")
```

---

## Custom Parameters

```python
from emno import EMNO, EMNOParams

params = EMNOParams(
    n_agents    = 40,      # population size
    max_iter    = 1000,    # maximum iterations
    seed        = 42,      # reproducibility
    verbose     = True,    # print progress
    tol         = 1e-15,   # early stop tolerance (0 = disabled)
)

result = EMNO(params).optimize(sphere, lb=-100, ub=100, dim=30)
```

---

## Built-in Benchmarks

```python
from emno.benchmarks import get_function, list_functions

print(list_functions())
# ['sphere', 'schwefel222', 'powell', 'rosenbrock', 'step',
#  'quartic', 'schwefel226', 'rastrigin', 'ackley', 'griewank',
#  'penalized1', 'penalized2', 'weierstrass']

bf     = get_function("ackley")
result = EMNO().optimize(bf.func, lb=bf.lb, ub=bf.ub, dim=bf.dim)
print(f"Ackley best: {result.best_score:.4e}")
```

---

## Statistical Benchmarking

```python
from emno.utils import run_benchmark, statistical_summary
from emno.benchmarks import get_function

emno  = EMNO(EMNOParams(n_agents=30, max_iter=500))
bf    = get_function("sphere")
stats = run_benchmark(emno, bf.func, lb=bf.lb, ub=bf.ub,
                      dim=bf.dim, n_runs=30)
print(statistical_summary(stats))
```

---

## Convergence Plot

```python
from emno.utils import plot_convergence

result = EMNO().optimize(sphere, lb=-100, ub=100, dim=30)
plot_convergence(result.convergence, title="Sphere D=30")
```

---

## Engineering Problems

```python
import math

def pressure_vessel(x):
    Ts, Th, R, L = x
    g1 = -Ts + 0.0193 * R
    g2 = -Th + 0.00954 * R
    g3 = -math.pi * R**2 * L - (4/3) * math.pi * R**3 + 1296000
    g4 = L - 240
    penalty = 1e6 * (max(0,g1)**2 + max(0,g2)**2
                     + max(0,g3)**2 + max(0,g4)**2)
    cost = (0.6224*Ts*R*L + 1.7781*Th*R**2
            + 3.1661*Ts**2*L + 19.84*Ts**2*R)
    return cost + penalty

result = EMNO(EMNOParams(n_agents=40, max_iter=1000)).optimize(
    pressure_vessel,
    lb=[0.0625, 0.0625, 10.0, 10.0],
    ub=[6.1875, 6.1875, 200.0, 200.0],
    dim=4
)
print(f"Pressure vessel cost: {result.best_score:.4f}")
```

---

## API Reference

### `EMNO(params=None)`
Main optimizer class.

**Methods:**
- `optimize(fobj, lb, ub, dim) → EMNOResult`

### `EMNOParams`
| Parameter | Default | Description |
|---|---|---|
| `n_agents` | 30 | Population size |
| `max_iter` | 500 | Maximum iterations |
| `elite_frac` | 0.33 | Elite fraction preserved on restart |
| `restart_window` | 25 | Stagnation window before restart |
| `restart_frac` | 0.45 | Fraction reinitialised on restart |
| `sca_gate` | 1e-6 | SCA disabled below this fitness |
| `levy_beta` | 1.5 | Lévy flight stability index |
| `de_cr` | 0.9 | DE crossover probability |
| `tol` | 0 | Early-stop tolerance (0 = off) |
| `seed` | None | Random seed |
| `verbose` | False | Print progress |

### `EMNOResult`
| Attribute | Type | Description |
|---|---|---|
| `best_score` | float | Best fitness found |
| `best_position` | ndarray | Corresponding solution vector |
| `convergence` | ndarray | Best fitness per iteration |
| `n_iter` | int | Iterations executed |
| `n_feval` | int | Function evaluations |

---

## Project Structure

```
emno/
├── emno/
│   ├── __init__.py       # Public API
│   ├── core.py           # EMNO algorithm
│   ├── benchmarks.py     # Test functions
│   └── utils.py          # Plotting & stats
├── tests/
│   └── test_emno.py      # Unit tests
├── examples/
│   └── basic_usage.py    # Usage examples
├── setup.py
├── requirements.txt
└── README.md
```

---

## Running Tests

```bash
pip install pytest
pytest tests/ -v
```

---

## Citation

If you use EMNO in your research, please cite:

```bibtex
@article{praneeth2025emno,
  author  = {Praneeth, N.},
  title   = {Enhanced Mycelium Network Optimization: A Bio-Inspired
             Metaheuristic with Chaotic Initialisation, Energy-Based
             Besiege, and Adaptive Restart},
  journal = {[Journal Name]},
  year    = {2025}
}
```

---

## License

MIT License — see [LICENSE](LICENSE) for details.
