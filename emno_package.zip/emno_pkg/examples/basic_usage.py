"""
examples/basic_usage.py
=======================
Basic usage examples for the EMNO package.
"""

import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

import numpy as np
import math
from emno import EMNO, EMNOParams
from emno.benchmarks import get_function, list_functions
from emno.utils import run_benchmark, statistical_summary

# ─────────────────────────────────────────────────────────────────────────────
# Example 1: Quick start — minimize Sphere function
# ─────────────────────────────────────────────────────────────────────────────

print("=" * 60)
print("Example 1: Sphere function (D=30)")
print("=" * 60)

result = EMNO().optimize(
    fobj=lambda x: float(np.sum(x**2)),
    lb=-100, ub=100, dim=30
)
print(f"Best score    : {result.best_score:.6e}")
print(f"Best position : {result.best_position[:5]} ...")
print(f"Iterations    : {result.n_iter}")
print(f"Func evals    : {result.n_feval}")


# ─────────────────────────────────────────────────────────────────────────────
# Example 2: Custom parameters
# ─────────────────────────────────────────────────────────────────────────────

print("\n" + "=" * 60)
print("Example 2: Ackley function with custom parameters (D=30)")
print("=" * 60)

params = EMNOParams(
    n_agents    = 40,
    max_iter    = 800,
    seed        = 42,
    verbose     = True,
)

def ackley(x):
    d  = len(x)
    s1 = np.sum(x**2)
    s2 = np.sum(np.cos(2 * math.pi * x))
    return float(-20 * math.exp(-0.2 * math.sqrt(s1/d))
                 - math.exp(s2/d) + 20 + math.e)

result = EMNO(params).optimize(ackley, lb=-32, ub=32, dim=30)
print(f"\nBest score : {result.best_score:.6e}")


# ─────────────────────────────────────────────────────────────────────────────
# Example 3: Using built-in benchmark functions
# ─────────────────────────────────────────────────────────────────────────────

print("\n" + "=" * 60)
print("Example 3: Built-in benchmark functions")
print("=" * 60)

print("Available functions:", list_functions())

for fname in ["sphere", "rastrigin", "griewank"]:
    bf = get_function(fname)
    emno = EMNO(EMNOParams(n_agents=30, max_iter=500, seed=0))
    result = emno.optimize(bf.func, lb=bf.lb, ub=bf.ub, dim=bf.dim)
    print(f"  {bf.name:20s}  best = {result.best_score:.4e}")


# ─────────────────────────────────────────────────────────────────────────────
# Example 4: Statistical benchmark over 30 runs
# ─────────────────────────────────────────────────────────────────────────────

print("\n" + "=" * 60)
print("Example 4: Statistical benchmark — Sphere D=30, 30 runs")
print("=" * 60)

emno   = EMNO(EMNOParams(n_agents=30, max_iter=500))
sphere = get_function("sphere")
stats  = run_benchmark(emno, sphere.func, lb=sphere.lb,
                       ub=sphere.ub, dim=sphere.dim,
                       n_runs=5, verbose=True)  # 5 for demo speed
print("\n" + statistical_summary(stats))


# ─────────────────────────────────────────────────────────────────────────────
# Example 5: Custom engineering problem
# ─────────────────────────────────────────────────────────────────────────────

print("\n" + "=" * 60)
print("Example 5: Pressure vessel design problem")
print("=" * 60)

def pressure_vessel(x):
    """
    Minimise cost of a cylindrical pressure vessel.
    x = [Ts, Th, R, L]
    """
    Ts, Th, R, L = x
    # Penalty method for constraints
    g1 = -Ts + 0.0193 * R
    g2 = -Th + 0.00954 * R
    g3 = -math.pi * R**2 * L - (4/3) * math.pi * R**3 + 1296000
    g4 = L - 240
    penalty = 1e6 * (max(0, g1)**2 + max(0, g2)**2
                     + max(0, g3)**2 + max(0, g4)**2)
    cost = (0.6224 * Ts * R * L
            + 1.7781 * Th * R**2
            + 3.1661 * Ts**2 * L
            + 19.84  * Ts**2 * R)
    return cost + penalty

lb = [0.0625, 0.0625, 10.0, 10.0]
ub = [6.1875, 6.1875, 200.0, 200.0]

emno   = EMNO(EMNOParams(n_agents=40, max_iter=800, seed=0))
result = emno.optimize(pressure_vessel, lb=lb, ub=ub, dim=4)
print(f"Best cost     : {result.best_score:.4f}")
print(f"Best design   : Ts={result.best_position[0]:.4f}  "
      f"Th={result.best_position[1]:.4f}  "
      f"R={result.best_position[2]:.4f}  "
      f"L={result.best_position[3]:.4f}")
